<!--<div class="app-wrapper-footer">-->
<!--    <div class="app-footer">-->
<!--        <div class="app-footer__inner">-->
<!--            <div class="app-footer-left">-->
<!--            </div>-->
<!--            <div class="app-footer-right">-->
<!--            </div>-->
<!--        </div>-->
<!--    </div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<!--</div>-->
<script type="text/javascript" src="/news/public/assets/js/main.js"></script>
<script src="/news/public/assets/js/site.js" asp-append-version="true"></script>
<script src="/news/public/assets/lib/datatables/datatables/jquery.dataTables.min.js"></script>
<script src="/news/public/assets/lib/datatables/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="/news/public/assets/lib/datatables/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="/news/public/assets/lib/datatables/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
</body>

</html>
