﻿function OpenAddslide() {
    document.getElementById('popUpmdl').style.display = "block";
}