<?php 
    static  $resource = "/news/public/views/img/";

?>